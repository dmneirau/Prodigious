<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/

/*Route::get('/', function () {
    return view('welcomeF');
});*/

Route::get('/', 'InfoController@info');

//Route::get('groups/{genre}/{city}', 'GroupsController@show');

Route::post('groups/show','GroupsController@show');

Route::get('new','NewController@index');