<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Group; 
use App\Musical_festival; 
use App\Musical_genre; 
use View;
use App\City; 

class GroupsController extends Controller
{
    
	public function index()
	{
		$info = Musical_festival::all();
		return view('groups', ['info' => $info->toArray()], ['groups' => $groups->toArray()]);
	}
	
	public function show(Request $request)
	{
		//dd($request->all());
		$groups = Group::whereRaw('genre = "'.$request->input('genre').'" and city = "'.$request->input('city').'"')->get();
		$info = Musical_festival::all();
		$cities = City::all();
		$genres = Musical_genre::all();
		if (!is_null($groups))
		{
			return View::make('groups', array('info' => $info->toArray(), 'groups' => $groups, 'genres' => $genres->toArray(), 'cities' => $cities->toArray()));
		}
		else
		{
			$groupE = Group::all();
			return View::make('groups', array('info' => $info->toArray(), 'groups' => $groupE->toArray(), 'genres' => $genres->toArray(), 'cities' => $cities->toArray()));
		}	
	}
}
