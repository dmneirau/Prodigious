<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Group; 
use App\Musical_festival; 
use App\Member; 
use App\Musical_genre; 
use View;
use App\City; 

class InfoController extends Controller
{
    public function info()
	{
		$info = Musical_festival::all();
		$groups = Group::where('id','>',0)->take(3)->get();
		$cities = City::all();
		$genres = Musical_genre::all();
		return View::make('welcomeF', array('info' => $info->toArray(), 'groups' => $groups, 'genres' => $genres->toArray(), 'cities' => $cities->toArray()));
	}
	
}
