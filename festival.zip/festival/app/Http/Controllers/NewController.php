<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Musical_festival; 
use App\Musical_genre; 
use View;
use App\City; 


class NewController extends Controller
{
    
	public function index()
	{
		$info = Musical_festival::all();
		$cities = City::all();
		$genres = Musical_genre::all();
		return View::make('new', array('info' => $info->toArray(), 'genres' => $genres->toArray(), 'cities' => $cities->toArray()));
	}
}
