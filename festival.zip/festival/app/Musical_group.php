<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Musical_group extends Model
{
    //
}
